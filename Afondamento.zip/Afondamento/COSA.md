# Practica guiada Git
#### Crear y moverme a prueba_git
![alt text](image.png)
#### Crear el archivo con "nano texto.txt"
![alt text](image-1.png)
![alt text](image-2.png)
#### Y lo mismo con script.sh
![alt text](image-3.png)
![alt text](image-4.png)
#### Y probamos el script
![alt text](image-5.png)
## Inicialización (init y status)
![alt text](image-7.png)
#### Cambio de master a main, y luego volvemos a master
![alt text](image-9.png)
#### Añadimos script.sh
![alt text](image-10.png)
#### Hacemos un commit y el status para ver que ha cambiado
![alt text](image-11.png)
#### Esta parte por mucho que pruebo no funciona pero bueno la incuyo igual
![alt text](image-12.png)
![alt text](image-13.png)
#### Añado texto y hago el commit
![alt text](image-14.png)
#### en mi caso no pone el nothing to commit ya que tengo mensaje.txt de hacer alguna prueba y no lo tengo añadido, asi que lo añadimos y ya lo pone
![alt text](image-15.png)
#### Añado una linea ("cuatro") a "texto.txt" y en el status ahora lo marca como modificado y no añadido
![alt text](image-16.png)
#### Lo añadimos y al hacer el status ahora lo marca en verde ya que esta añadido
![alt text](image-17.png)
#### Añadimos 5 pero sigue saliendo en verde, y abajo en rojo, ya que la version en la que añadimos 4 sigue añadida, asi que si hacemos un commit se guardaria esa version y no la mas nueva
![alt text](image-18.png)
#### Volvemos a añadirlo y en el status ya sale solo en verde ya que la ultima version esta añadida
![alt text](image-19.png)
#### Y hacemos el commit
![alt text](image-20.png)
#### Hacemos el commit y el show que muestra informacion sobre la ultima version modificada
![alt text](image-21.png)
#### Ahora hacemos el log para ver los cambios realizados en forma de historico
![alt text](image-22.png)
#### Añadmos en "texto.txt" la linea seis y borramos la 3, hacemos un diff y muestra las differencias desde el ultimo commit
![alt text](image-23.png)
#### Hacemos un commit
![alt text](image-24.png)
#### Ahora en el diff sale que hemos añadido siete, tambien se me habia colado un salto de linea pero no es relevante.
![alt text](image-25.png)
#### Creamos .gitignore
![alt text](image-26.png)
![alt text](image-27.png)
#### Se le escribe esto
![alt text](image-28.png)
#### Creamos hola.java
![alt text](image-29.png)
#### Creamos temporal~ e importante~
![alt text](image-30.png)
#### antes ya habia complilado hola.java asi que ya aparece el .class
![alt text](image-31.png)
#### Hacemos el status
![alt text](image-32.png)
#### Añadimos lo que esta pendiente y hacemos el commit
![alt text](image-33.png)
#### Listamos
![alt text](image-34.png)
#### Hacemos el show de uno de los commits antiguos utilizando el hash
![alt text](image-35.png)
#### Hacemos un tag
![alt text](image-36.png)
#### ahora con este comando vemos el tag en nuestra version actual
![alt text](image-37.png)
#### Tambien podemos hacer un show utilizando el tag para no tener que usar la clave compleja
![alt text](image-38.png)
#### Despues de añadir un archivo
![alt text](image-39.png)
#### Añadirlo
![alt text](image-40.png)
#### Y hacer el commit
![alt text](image-41.png)
#### hacemos el checkout de la version antigua y volvemos atras
![alt text](image-42.png)
#### Y con checkout master volvemos a la mas nueva
![alt text](image-43.png)
#### Creamos una nueva rama "Prueba"
![alt text](image-44.png)
#### y con un log vemos la rama Prueba a parte de la de master
![alt text](image-45.png)
![alt text](image-46.png)
#### Cambiamos a prueba
![alt text](image-47.png)
#### Ahora HEAD apunta a PRUEBA
![alt text](image-48.png)
#### Hacemos un commit en Prueba y master queda atras
![alt text](image-49.png)
#### Cambiamos hola.java
![alt text](image-50.png)
#### Hacemos el commit
![alt text](image-51.png)
![alt text](image-52.png)
#### Cambiamos a master y el java no tiene la linea añadida
![alt text](image-53.png)
#### Fusionamos Prueba y master con merge
![alt text](image-54.png)
#### Eliminamos importante~
![alt text](image-55.png)
#### Se quitan los .class del seguimiento
![alt text](image-56.png)
#### Lo subimos a github
![alt text](image-57.png)
![alt text](image-58.png)
![alt text](image-59.png)
![alt text](image-60.png)
![alt text](image-61.png)